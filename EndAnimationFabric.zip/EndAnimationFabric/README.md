# EndAnimation (Fabric 1.20.1)

Серверный мод: искры -> взрывная волна -> световой столб, воронка, кольца, лучи, рябь, розовое облако -> финал.
Нужен Fabric Loader 0.15+ и Fabric API 0.92.x для 1.20.1. На клиентах мод ставить НЕ нужно
(в одиночной игре ставится как обычный мод).

Команды (OP, уровень 2):
- /endanim start [camera|nocamera]  - запуск там, где стоишь
- /endanim stop
- /endanim reload

Настройки: config/endanimation.json (density, beamHeight, maxRingRadius, cameraDefault).

Сборка: GitHub Actions (.github/workflows/build.yml) - jar в Releases.
