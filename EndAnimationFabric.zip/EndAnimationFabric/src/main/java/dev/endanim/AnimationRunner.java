package dev.endanim;

import net.minecraft.particle.DustParticleEffect;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.GameMode;
import org.joml.Vector3f;

import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Таймлайн (20 тиков = 1 сек, всего 30 сек):
 *   0-9 c    искры поднимаются над точкой, нарастая
 *   9-10 c   взрывная волна (сферы розовых частиц)
 *   10-27 c  световой столб, воронка, кольца, лучи, рябь по земле, розовое облако
 *   27-30 c  затухание, схлопывающееся кольцо и финальная вспышка
 */
public final class AnimationRunner {

    static final int SPARK_END = 180;
    static final int BLAST_END = 200;
    static final int MAIN_END = 540;
    static final int TOTAL = 600;

    private static final Vector3f PINK = new Vector3f(1.0f, 0.2f, 1.0f);
    private static final Vector3f LIGHT = new Vector3f(1.0f, 0.67f, 1.0f);
    private static final Vector3f WHITE = new Vector3f(1.0f, 1.0f, 1.0f);
    private static final Vector3f PURPLE = new Vector3f(0.63f, 0.0f, 0.9f);

    private record Key(int tick, double px, double py, double pz, double lx, double ly, double lz) {}

    /** Ключевые кадры камеры относительно центра: позиция и точка взгляда. */
    private static final List<Key> KEYS = List.of(
            new Key(0, 0, 1.8, 3.5, 0, 1.5, 0),
            new Key(60, 0, 3.0, 8.0, 0, 3.0, 0),
            new Key(130, 0, 5.0, 18.0, 0, 5.0, 0),
            new Key(180, 0, 4.0, 38.0, 0, 6.0, 0),
            new Key(215, 0, 6.0, 42.0, 0, 20.0, 0),
            new Key(290, 0, 2.0, 30.0, 0, 40.0, 0),
            new Key(380, 4, 3.0, 34.0, 0, 28.0, 0),
            new Key(470, -6, 8.0, 44.0, 0, 18.0, 0),
            new Key(540, 0, 24.0, 62.0, 0, 10.0, 0),
            new Key(600, 0, 34.0, 78.0, 0, 8.0, 0));

    private final ServerWorld world;
    private final double cx, cy, cz;
    private final double density;
    private final double beamH;
    private final double maxR;

    private ServerPlayerEntity cam;
    private GameMode oldMode;
    private double ox, oy, oz;
    private float oyaw, opitch;

    private int tick = 0;
    private boolean finished = false;

    public AnimationRunner(ServerWorld world, double cx, double cy, double cz, ServerPlayerEntity cam) {
        this.world = world;
        this.cx = cx;
        this.cy = cy;
        this.cz = cz;
        Config c = Config.get();
        this.density = Math.max(0.1, c.density);
        this.beamH = c.beamHeight;
        this.maxR = c.maxRingRadius;
        this.cam = cam;
        if (cam != null) {
            this.oldMode = cam.interactionManager.getGameMode();
            this.ox = cam.getX();
            this.oy = cam.getY();
            this.oz = cam.getZ();
            this.oyaw = cam.getYaw();
            this.opitch = cam.getPitch();
            cam.changeGameMode(GameMode.SPECTATOR);
        }
    }

    public boolean isFinished() {
        return finished;
    }

    public void stop() {
        if (finished) return;
        finished = true;
        if (cam != null && !cam.isRemoved()) {
            cam.changeGameMode(oldMode);
            cam.teleport(world, ox, oy, oz, oyaw, opitch);
        }
        cam = null;
    }

    public void tick() {
        if (finished) return;
        int t = tick++;
        if (t >= TOTAL) {
            stop();
            return;
        }
        if (t < SPARK_END) {
            spark(t);
        } else if (t < BLAST_END) {
            int k = t - SPARK_END;
            blast(k);
            mainPhase(k, k / 20.0);
        } else if (t < MAIN_END) {
            mainPhase(t - BLAST_END, 1.0);
        } else {
            finale(t - MAIN_END);
        }
        camera(t);
    }

    // ------------------------------------------------------------ helpers

    private static double rnd() {
        return ThreadLocalRandom.current().nextDouble();
    }

    /** Отправляет частицу всем игрокам мира с force=true (видна на расстоянии до 512 блоков). */
    private void emit(ParticleEffect fx, double x, double y, double z, int count,
                      double dx, double dy, double dz, double speed) {
        for (ServerPlayerEntity p : world.getPlayers()) {
            world.spawnParticles(p, fx, true, x, y, z, count, dx, dy, dz, speed);
        }
    }

    private void dust(double x, double y, double z, Vector3f color, float size) {
        emit(new DustParticleEffect(color, size), x, y, z, 1, 0, 0, 0, 0);
    }

    private void rod(double x, double y, double z, double vx, double vy, double vz, double speed) {
        emit(ParticleTypes.END_ROD, x, y, z, 0, vx, vy, vz, speed);
    }

    private void ring(double y, double r, int n, double rot, Vector3f color, float size) {
        for (int i = 0; i < n; i++) {
            double a = rot + 2 * Math.PI * i / n;
            dust(cx + Math.cos(a) * r, y, cz + Math.sin(a) * r, color, size);
        }
    }

    private void sound(SoundEvent s, float vol, float pitch) {
        world.playSound(null, cx, cy + 1.5, cz, s, SoundCategory.MASTER, vol, pitch);
    }

    // ------------------------------------------------------------ phases

    private void spark(int t) {
        double p = t / (double) SPARK_END;
        int n = (int) Math.ceil((3 + 22 * p) * density);
        double spread = 0.4 + 2.2 * p;
        for (int i = 0; i < n; i++) {
            double a = rnd() * 2 * Math.PI;
            double d = Math.sqrt(rnd()) * spread;
            double x = cx + Math.cos(a) * d;
            double z = cz + Math.sin(a) * d;
            double y = cy + 1.0 + rnd() * 0.6;
            if (rnd() < 0.45) {
                rod(x, y, z, (rnd() - 0.5) * 0.4, 1.0, (rnd() - 0.5) * 0.4, 0.08 + p * 0.12);
            } else {
                dust(x, y + rnd() * 3.0, z, rnd() < 0.6 ? PINK : LIGHT, 1.0f + (float) rnd() * 1.5f);
            }
        }
        // пульсирующее кольцо раз в секунду
        double pr = (t % 20) / 20.0 * (2 + 6 * p);
        ring(cy + 1.0, pr, (int) (24 * density) + 8, t * 0.1, LIGHT, 1.0f);

        if (t == 0) sound(SoundEvents.BLOCK_BEACON_ACTIVATE, 3f, 0.5f);
        if (t % 40 == 0 && t > 0) sound(SoundEvents.BLOCK_PORTAL_AMBIENT, 2f, (float) (0.5 + p));
    }

    private void blast(int k) {
        double r = 1 + k * 2.2;
        int n = (int) (150 * density);
        double golden = Math.PI * (3 - Math.sqrt(5));
        for (int i = 0; i < n; i++) {
            double yy = 1 - 2.0 * i / (n - 1.0);
            double rad = Math.sqrt(Math.max(0, 1 - yy * yy));
            double th = golden * i + k;
            double dx = Math.cos(th) * rad;
            double dz = Math.sin(th) * rad;
            double x = cx + dx * r;
            double y = cy + 1.2 + yy * r * 0.7;
            double z = cz + dz * r;
            dust(x, y, z, i % 3 == 0 ? WHITE : PINK, 2.5f);
            if (i % 4 == 0) rod(x, y, z, dx, yy, dz, 0.2);
        }
        if (k == 0) {
            emit(ParticleTypes.EXPLOSION_EMITTER, cx, cy + 1.2, cz, 1, 0, 0, 0, 0);
            sound(SoundEvents.ENTITY_ENDER_DRAGON_GROWL, 8f, 0.7f);
            sound(SoundEvents.ENTITY_GENERIC_EXPLODE, 8f, 0.6f);
        }
    }

    private void mainPhase(int m, double intensity) {
        double dens = density * Math.max(0.0, intensity);
        double base = cy + 1.0;

        // световой столб
        int nb = (int) Math.ceil(70 * dens);
        for (int i = 0; i < nb; i++) {
            double y = base + Math.pow(rnd(), 1.4) * beamH;
            rod(cx, y, cz, 0, 1, 0, 0.03);
            if (i % 2 == 0) dust(cx + (rnd() - 0.5) * 0.3, y, cz + (rnd() - 0.5) * 0.3, WHITE, 1.3f);
        }

        // воронка: широкая внизу, сужается кверху
        int nf = (int) Math.ceil(60 * dens);
        for (int i = 0; i < nf; i++) {
            double h = Math.pow(rnd(), 1.5) * 60.0;
            double rmax = 0.6 + 7.0 * (1 - h / 60.0);
            double d = Math.sqrt(rnd()) * rmax;
            double a = rnd() * 2 * Math.PI;
            dust(cx + Math.cos(a) * d, base + h, cz + Math.sin(a) * d, rnd() < 0.5 ? PINK : PURPLE, 3.0f);
        }

        // расходящиеся кольца в небе
        if (m % 2 == 0) {
            for (int i = 0; i < 6; i++) {
                double phase = ((m * 0.012) + i / 6.0) % 1.0;
                double y = base + 5 + phase * (beamH * 0.8);
                double r = 3 + phase * maxR;
                int n = (int) (Math.min(180, Math.max(30, r * 5)) * Math.max(0.2, dens));
                float size = (float) (1.8 - phase * 1.0);
                Vector3f col = phase < 0.3 ? WHITE : (i % 2 == 0 ? PINK : LIGHT);
                double rot = m * 0.05 * (i % 2 == 0 ? 1 : -1);
                ring(y, r, n, rot, col, size);
            }
        }

        // диагональные лучи
        if (m % 2 == 1) {
            int rays = 8;
            double el = 0.55;
            double step = 1.5 / Math.max(0.3, dens);
            for (int j = 0; j < rays; j++) {
                double a = 2 * Math.PI * j / rays + m * 0.01;
                double dx = Math.cos(a) * Math.cos(el);
                double dy = Math.sin(el);
                double dz = Math.sin(a) * Math.cos(el);
                for (double s = 0; s < 48; s += step) {
                    double x = cx + dx * s, y = base + 8 + dy * s, z = cz + dz * s;
                    dust(x, y, z, WHITE, 1.0f);
                    if (rnd() < 0.3) rod(x, y, z, 0, 0, 0, 0);
                }
            }
        }

        // рябь по земле
        if (m % 2 == 0) {
            for (int off : new int[]{0, 20}) {
                double r = (m * 0.9 + off) % 40;
                int n = (int) (r * 5 + 12);
                ring(cy + 0.3, r, n, 0, WHITE, 1.2f);
            }
        }

        // розовое облако у основания
        int nc = (int) Math.ceil(45 * dens);
        for (int i = 0; i < nc; i++) {
            double a = rnd() * 2 * Math.PI;
            double d = 8 + rnd() * 8;
            dust(cx + Math.cos(a) * d, cy + rnd() * 7, cz + Math.sin(a) * d, rnd() < 0.5 ? PINK : LIGHT, 3.5f);
        }

        if (m % 40 == 0) sound(SoundEvents.BLOCK_BEACON_AMBIENT, 6f, 1f);
        if (m == 0) sound(SoundEvents.ENTITY_LIGHTNING_BOLT_THUNDER, 8f, 0.8f);
    }

    private void finale(int f) {
        double inten = Math.max(0.05, 1.0 - f / 60.0);
        mainPhase(MAIN_END - BLAST_END + f, inten);

        double r = maxR * (1.0 - f / 60.0);
        if (r > 0.5) {
            int n = (int) (Math.max(40, r * 6) * density);
            ring(cy + 3, r, n, f * 0.2, PINK, 2.5f);
            ring(cy + 3.5, r * 0.98, n, -f * 0.2, WHITE, 1.4f);
        }
        if (f == 58) {
            blast(8);
            emit(ParticleTypes.EXPLOSION_EMITTER, cx, cy + 1.2, cz, 1, 0, 0, 0, 0);
            sound(SoundEvents.ENTITY_GENERIC_EXPLODE, 8f, 0.5f);
        }
    }

    // ------------------------------------------------------------ camera

    private void camera(int t) {
        if (cam == null) return;
        if (cam.isRemoved() || cam.getWorld() != world) {
            cam = null;
            return;
        }
        Key a = KEYS.get(KEYS.size() - 1);
        Key b = a;
        double u = 1.0;
        for (int i = 0; i < KEYS.size() - 1; i++) {
            Key k0 = KEYS.get(i), k1 = KEYS.get(i + 1);
            if (t >= k0.tick() && t <= k1.tick()) {
                a = k0;
                b = k1;
                u = (t - k0.tick()) / (double) (k1.tick() - k0.tick());
                break;
            }
        }
        double s = u * u * (3 - 2 * u); // smoothstep
        double px = a.px() + (b.px() - a.px()) * s;
        double py = a.py() + (b.py() - a.py()) * s;
        double pz = a.pz() + (b.pz() - a.pz()) * s;
        double lx = a.lx() + (b.lx() - a.lx()) * s;
        double ly = a.ly() + (b.ly() - a.ly()) * s;
        double lz = a.lz() + (b.lz() - a.lz()) * s;

        double dx = lx - px, dy = ly - py, dz = lz - pz;
        double horiz = Math.sqrt(dx * dx + dz * dz);
        float yaw = (float) (MathHelper.atan2(-dx, dz) * 180.0 / Math.PI);
        float pitch = (float) (-(MathHelper.atan2(dy, horiz) * 180.0 / Math.PI));
        cam.teleport(world, cx + px, cy + py, cz + pz, yaw, pitch);
    }
}
