package dev.endanim;

import com.mojang.brigadier.exceptions.CommandSyntaxException;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class EndAnimMod implements ModInitializer {
    public static final Logger LOGGER = LoggerFactory.getLogger("endanimation");

    private static AnimationRunner current;

    @Override
    public void onInitialize() {
        Config.load();

        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) ->
                dispatcher.register(CommandManager.literal("endanim")
                        .requires(src -> src.hasPermissionLevel(2))
                        .executes(ctx -> start(ctx.getSource(), Config.get().cameraDefault))
                        .then(CommandManager.literal("start")
                                .executes(ctx -> start(ctx.getSource(), Config.get().cameraDefault))
                                .then(CommandManager.literal("camera")
                                        .executes(ctx -> start(ctx.getSource(), true)))
                                .then(CommandManager.literal("nocamera")
                                        .executes(ctx -> start(ctx.getSource(), false))))
                        .then(CommandManager.literal("stop")
                                .executes(ctx -> stop(ctx.getSource())))
                        .then(CommandManager.literal("reload")
                                .executes(ctx -> {
                                    Config.load();
                                    ctx.getSource().sendFeedback(() -> Text.literal("Конфиг перезагружен."), false);
                                    return 1;
                                }))));

        ServerTickEvents.END_SERVER_TICK.register(server -> {
            if (current != null) {
                current.tick();
                if (current.isFinished()) current = null;
            }
        });

        ServerLifecycleEvents.SERVER_STOPPING.register(server -> {
            if (current != null) {
                current.stop();
                current = null;
            }
        });
    }

    private static int start(ServerCommandSource src, boolean camera) throws CommandSyntaxException {
        ServerPlayerEntity p = src.getPlayerOrThrow();
        if (current != null) current.stop();
        current = new AnimationRunner(p.getServerWorld(),
                Math.floor(p.getX()) + 0.5, Math.floor(p.getY()), Math.floor(p.getZ()) + 0.5,
                camera ? p : null);
        src.sendFeedback(() -> Text.literal(camera ? "Анимация запущена (с камерой)." : "Анимация запущена."), false);
        return 1;
    }

    private static int stop(ServerCommandSource src) {
        if (current != null) {
            current.stop();
            current = null;
            src.sendFeedback(() -> Text.literal("Анимация остановлена."), false);
        } else {
            src.sendFeedback(() -> Text.literal("Сейчас ничего не запущено."), false);
        }
        return 1;
    }
}
