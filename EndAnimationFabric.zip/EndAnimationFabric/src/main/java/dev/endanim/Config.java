package dev.endanim;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.Reader;
import java.nio.file.Files;
import java.nio.file.Path;

/** Конфиг: config/endanimation.json */
public final class Config {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static Config instance = new Config();

    /** Множитель количества частиц (0.3 - слабые ПК, 1.0 - как в видео, 2.0 - плотно). */
    public double density = 1.0;
    /** Высота светового столба в блоках. */
    public double beamHeight = 100.0;
    /** Максимальный радиус колец в блоках. */
    public double maxRingRadius = 40.0;
    /** Включать камеру по умолчанию (игрок на время анимации уходит в SPECTATOR). */
    public boolean cameraDefault = false;

    public static Config get() {
        return instance;
    }

    public static void load() {
        Path p = FabricLoader.getInstance().getConfigDir().resolve("endanimation.json");
        try {
            if (Files.exists(p)) {
                try (Reader r = Files.newBufferedReader(p)) {
                    Config c = GSON.fromJson(r, Config.class);
                    if (c != null) instance = c;
                }
            } else {
                Files.writeString(p, GSON.toJson(instance));
            }
        } catch (Exception e) {
            EndAnimMod.LOGGER.error("Не удалось прочитать конфиг, использую значения по умолчанию", e);
        }
    }
}
