@echo off
setlocal EnableExtensions
chcp 65001 >nul
cd /d "%~dp0"
title EndAnimation - auto build

set "HERE=%~dp0"
set "TOOLS=%HERE%.tools"
set "OUT=%HERE%output"
set "PROJ=%HERE%"
set "MVNVER=3.9.9"

if exist "%HERE%pom.xml" goto havesrc
if not exist "%HERE%EndAnimation.zip" goto nosrc
echo [1/4] Unpacking EndAnimation.zip ...
powershell -NoProfile -ExecutionPolicy Bypass -Command "Expand-Archive -LiteralPath '%HERE%EndAnimation.zip' -DestinationPath '%HERE%' -Force"
if errorlevel 1 goto fail
set "PROJ=%HERE%EndAnimation\"
goto jdk

:nosrc
echo [ERROR] Neither pom.xml nor EndAnimation.zip found next to build.bat
goto fail

:havesrc
echo [1/4] Sources already unpacked

:jdk
echo [2/4] Checking JDK 21 ...
where javac >nul 2>nul
if errorlevel 1 goto jdkdl
set "JV="
for /f "tokens=2" %%v in ('javac -version 2^>^&1') do set "JV=%%v"
for /f "delims=. tokens=1" %%m in ("%JV%") do set "JMAJOR=%%m"
if "%JMAJOR%"=="" goto jdkdl
if %JMAJOR% GEQ 21 goto mvn

:jdkdl
if exist "%TOOLS%\jdk\bin\javac.exe" goto jdkset
if not exist "%TOOLS%" mkdir "%TOOLS%"
echo     Downloading Temurin JDK 21 ...
powershell -NoProfile -ExecutionPolicy Bypass -Command "$ProgressPreference='SilentlyContinue'; [Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12; Invoke-WebRequest -UseBasicParsing 'https://api.adoptium.net/v3/binary/latest/21/ga/windows/x64/jdk/hotspot/normal/eclipse' -OutFile '%TOOLS%\jdk.zip'; Expand-Archive -LiteralPath '%TOOLS%\jdk.zip' -DestinationPath '%TOOLS%\jdk_tmp' -Force; $d = Get-ChildItem '%TOOLS%\jdk_tmp' -Directory | Select-Object -First 1; Move-Item $d.FullName '%TOOLS%\jdk'; Remove-Item '%TOOLS%\jdk_tmp','%TOOLS%\jdk.zip' -Recurse -Force"
if errorlevel 1 goto fail
:jdkset
set "JAVA_HOME=%TOOLS%\jdk"
set "PATH=%TOOLS%\jdk\bin;%PATH%"

:mvn
echo [3/4] Checking Maven ...
where mvn >nul 2>nul
if not errorlevel 1 goto build
if exist "%TOOLS%\maven\bin\mvn.cmd" goto mvnset
if not exist "%TOOLS%" mkdir "%TOOLS%"
echo     Downloading Apache Maven %MVNVER% ...
powershell -NoProfile -ExecutionPolicy Bypass -Command "$ProgressPreference='SilentlyContinue'; [Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12; Invoke-WebRequest -UseBasicParsing 'https://archive.apache.org/dist/maven/maven-3/%MVNVER%/binaries/apache-maven-%MVNVER%-bin.zip' -OutFile '%TOOLS%\maven.zip'; Expand-Archive -LiteralPath '%TOOLS%\maven.zip' -DestinationPath '%TOOLS%\mvn_tmp' -Force; $d = Get-ChildItem '%TOOLS%\mvn_tmp' -Directory | Select-Object -First 1; Move-Item $d.FullName '%TOOLS%\maven'; Remove-Item '%TOOLS%\mvn_tmp','%TOOLS%\maven.zip' -Recurse -Force"
if errorlevel 1 goto fail
:mvnset
set "PATH=%TOOLS%\maven\bin;%PATH%"

:build
echo [4/4] Building ...
pushd "%PROJ%"
call mvn -B -q clean package
if errorlevel 1 (
  popd
  goto fail
)
popd
if not exist "%OUT%" mkdir "%OUT%"
copy /y "%PROJ%target\EndAnimation-*.jar" "%OUT%\" >nul
echo.
echo DONE: %OUT%
dir /b "%OUT%\EndAnimation-*.jar"
echo Put the jar into the plugins folder of your Paper 1.21.11 server and restart.
pause
exit /b 0

:fail
echo.
echo [ERROR] Build failed. See messages above.
pause
exit /b 1
