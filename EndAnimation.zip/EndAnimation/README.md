# EndAnimation (Paper 1.21.11)

Анимация по видео: искры над точкой → взрывная волна → световой столб с воронкой,
расходящимися кольцами, диагональными лучами, рябью по земле и розовым облаком → финал.

## Сборка
- Windows: двойной клик по `build.bat`
- Linux/macOS: `bash build.sh`

Скрипт сам распакует `EndAnimation.zip` (если лежит рядом), скачает JDK 21 и Maven (если их нет)
и положит jar в папку `output/`. Нужен интернет при первой сборке.

## Использование
Jar в `plugins/`, затем:
- `/endanim start` — запуск в точке, где стоишь
- `/endanim start camera` — то же + кинематографичная камера (на время анимации SPECTATOR)
- `/endanim stop`, `/endanim reload`

Право: `endanim.use` (по умолчанию op). Настройки — `plugins/EndAnimation/config.yml`
(`density` — плотность частиц, снижай при лагах).

## Сборка на GitHub
Залей содержимое проекта (pom.xml в корне репозитория, вместе с папкой `.github`) и открой
вкладку Actions: jar появится в Artifacts как `EndAnimation-jar`.
Для релиза: `git tag v1.0.0 && git push --tags`, jar прикрепится к Release автоматически.
