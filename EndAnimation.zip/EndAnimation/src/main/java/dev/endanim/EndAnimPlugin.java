package dev.endanim;

import org.bukkit.Location;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public final class EndAnimPlugin extends JavaPlugin implements CommandExecutor, TabCompleter {

    private AnimationRunner current;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        var cmd = getCommand("endanim");
        if (cmd != null) {
            cmd.setExecutor(this);
            cmd.setTabCompleter(this);
        }
    }

    @Override
    public void onDisable() {
        if (current != null) {
            current.stop();
            current = null;
        }
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        String sub = args.length == 0 ? "start" : args[0].toLowerCase(Locale.ROOT);
        switch (sub) {
            case "start" -> {
                if (!(sender instanceof Player p)) {
                    sender.sendMessage("Команду может использовать только игрок.");
                    return true;
                }
                if (current != null) current.stop();
                boolean cam = getConfig().getBoolean("camera-default", false);
                if (args.length > 1) {
                    if (args[1].equalsIgnoreCase("camera")) cam = true;
                    if (args[1].equalsIgnoreCase("nocamera")) cam = false;
                }
                Location base = p.getLocation().getBlock().getLocation().add(0.5, 0, 0.5);
                current = new AnimationRunner(this, base, cam ? p : null);
                current.start();
                sender.sendMessage("Анимация запущена" + (cam ? " (с камерой)." : "."));
            }
            case "stop" -> {
                if (current != null) {
                    current.stop();
                    current = null;
                    sender.sendMessage("Анимация остановлена.");
                } else {
                    sender.sendMessage("Сейчас ничего не запущено.");
                }
            }
            case "reload" -> {
                reloadConfig();
                sender.sendMessage("Конфиг перезагружен.");
            }
            default -> sender.sendMessage("Использование: /endanim <start|stop|reload> [camera|nocamera]");
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        List<String> out = new ArrayList<>();
        if (args.length == 1) {
            for (String s : List.of("start", "stop", "reload"))
                if (s.startsWith(args[0].toLowerCase(Locale.ROOT))) out.add(s);
        } else if (args.length == 2 && args[0].equalsIgnoreCase("start")) {
            for (String s : List.of("camera", "nocamera"))
                if (s.startsWith(args[1].toLowerCase(Locale.ROOT))) out.add(s);
        }
        return out;
    }
}
