#!/usr/bin/env bash
# Авто-распаковка + авто-сборка EndAnimation (Linux / macOS).
# Положи рядом с EndAnimation.zip (или запусти внутри распакованного проекта) и выполни:  bash build.sh
set -euo pipefail
cd "$(dirname "$0")"
HERE="$(pwd)"
TOOLS="$HERE/.tools"
OUT="$HERE/output"
PROJ="$HERE"
MVN_VER="3.9.9"

if [ ! -f pom.xml ]; then
  [ -f EndAnimation.zip ] || { echo "[ERROR] Нет ни pom.xml, ни EndAnimation.zip рядом со скриптом"; exit 1; }
  echo "[1/4] Распаковка EndAnimation.zip ..."
  if command -v unzip >/dev/null 2>&1; then unzip -oq EndAnimation.zip
  else python3 -c "import zipfile; zipfile.ZipFile('EndAnimation.zip').extractall('.')"; fi
  PROJ="$HERE/EndAnimation"
else
  echo "[1/4] Исходники уже распакованы"
fi

fetch() { # url dest
  if command -v curl >/dev/null 2>&1; then curl -fL --retry 3 -o "$2" "$1"
  else wget -O "$2" "$1"; fi
}

echo "[2/4] Проверка JDK 21 ..."
need_jdk=1
if command -v javac >/dev/null 2>&1; then
  major="$(javac -version 2>&1 | awk '{print $2}' | cut -d. -f1)"
  [ "${major:-0}" -ge 21 ] 2>/dev/null && need_jdk=0
fi
if [ "$need_jdk" = 1 ]; then
  if [ ! -x "$TOOLS/jdk/bin/javac" ]; then
    mkdir -p "$TOOLS"
    case "$(uname -m)" in aarch64|arm64) A=aarch64;; *) A=x64;; esac
    case "$(uname -s)" in Darwin) O=mac;; *) O=linux;; esac
    echo "    Скачиваю Temurin JDK 21 ($O/$A) ..."
    fetch "https://api.adoptium.net/v3/binary/latest/21/ga/$O/$A/jdk/hotspot/normal/eclipse" "$TOOLS/jdk.tar.gz"
    mkdir -p "$TOOLS/jdk"
    tar -xzf "$TOOLS/jdk.tar.gz" -C "$TOOLS/jdk" --strip-components=1
    rm -f "$TOOLS/jdk.tar.gz"
  fi
  if [ -d "$TOOLS/jdk/Contents/Home" ]; then export JAVA_HOME="$TOOLS/jdk/Contents/Home"; else export JAVA_HOME="$TOOLS/jdk"; fi
  export PATH="$JAVA_HOME/bin:$PATH"
fi

echo "[3/4] Проверка Maven ..."
if ! command -v mvn >/dev/null 2>&1; then
  if [ ! -x "$TOOLS/maven/bin/mvn" ]; then
    mkdir -p "$TOOLS/maven"
    echo "    Скачиваю Apache Maven $MVN_VER ..."
    fetch "https://archive.apache.org/dist/maven/maven-3/$MVN_VER/binaries/apache-maven-$MVN_VER-bin.tar.gz" "$TOOLS/maven.tar.gz"
    tar -xzf "$TOOLS/maven.tar.gz" -C "$TOOLS/maven" --strip-components=1
    rm -f "$TOOLS/maven.tar.gz"
  fi
  export PATH="$TOOLS/maven/bin:$PATH"
fi

echo "[4/4] Сборка ..."
( cd "$PROJ" && mvn -B -q clean package )
mkdir -p "$OUT"
cp -f "$PROJ"/target/EndAnimation-*.jar "$OUT/"
echo
echo "ГОТОВО: $OUT/$(ls "$OUT" | grep '^EndAnimation-.*jar$' | head -1)"
echo "Положи jar в папку plugins/ сервера Paper 1.21.11 и перезапусти сервер."
